namespace CleaArchitecture.Application.Abstractions.Clock;

public interface IDateTimeProvider
{
    DateTime currentTime {get;}
}